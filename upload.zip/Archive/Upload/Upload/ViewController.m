//
//  ViewController.m
//  Upload
//
//  Created by MAC OS on 7/20/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import "ViewController.h"
#import "AFURLSessionManager.h"
#import "AFHTTPSessionManager.h"

@interface ViewController ()
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UITapGestureRecognizer *tep=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imagepik)];
    tep.numberOfTapsRequired=1;
    _image.userInteractionEnabled=YES;
    [_image addGestureRecognizer:tep];
}

-(void)imagepik{
    UIImagePickerController *pkr=[[UIImagePickerController alloc]init];
    pkr.delegate=self;
    pkr.sourceType=UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    [self presentViewController:pkr animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:nil];
    UIImage *img=info[UIImagePickerControllerOriginalImage];
    _image.image=img;
}


- (IBAction)upload:(id)sender {
    
    NSString *alphabet  = @"Image";
    NSMutableString *s = [NSMutableString stringWithCapacity:20];
    for (NSUInteger i = 0U; i < 20; i++) {
        [s appendFormat:@"%C",[alphabet characterAtIndex:arc4random_uniform([alphabet length])]];
    }
    [s appendString:@".jpg"];
    
    NSURL *URL = [NSURL URLWithString:@"http://localhost"];
    NSDictionary *parameters = @{@"username": @"tops", @"password" : @"surat"};
    NSData *imageData = UIImageJPEGRepresentation(self.image.image, 0.5);
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithBaseURL:URL];
    [manager POST:@"/rajni/index.php" parameters:parameters constructingBodyWithBlock:^ void(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:imageData name:@"file" fileName:s mimeType:@"image/jpeg"];
    }
          success:^ void(NSURLSessionDataTask *operaton , id responseObject) {
              NSLog(@"success%@",responseObject);
          } failure:^ void(NSURLSessionDataTask * opration, NSError * err) {
              NSLog(@"Error: %@", err);
          }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)getdata:(id)sender {
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:@"http://api.androidhive.info/contacts/"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:request completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        if (error) {
            NSLog(@"Error: %@", error);
        } else {
            NSLog(@"%@ %@", response, responseObject);
        }
    }];
}

- (IBAction)getperameter:(id)sender {
    AFHTTPSessionManager *manager =[[AFHTTPSessionManager alloc]init];
    
    NSURLSessionDataTask *datatask = [manager GET:@"http://api.androidhive.info/contacts/" parameters:nil success:^ void(NSURLSessionDataTask * task, id responobject) {
        
        NSLog(@"%@",responobject);
        
        
        
        
    } failure:^ void(NSURLSessionDataTask * task1, NSError * err) {
        
        NSLog(@"%@",task1.description);
        
        
    }];
    [datatask resume];
}

- (IBAction)Postdata:(id)sender {
    AFHTTPSessionManager *manager =[[AFHTTPSessionManager alloc]init];
    
    NSDictionary *dic1 =[NSDictionary dictionaryWithObjectsAndKeys:@"2",@"sid",@"surat",@"city",@"123456789",@"mob", nil];
    NSURLSessionDataTask *datatask =[manager POST:@"http://localhost/demo/test1.php" parameters:dic1 success:^ void(NSURLSessionDataTask * data, id responceobject ) {
        
        NSLog(@"%@",responceobject);
        
    } failure:^ void(NSURLSessionDataTask * fal, NSError * err) {
        
        NSLog(@"%@",err);
        
    }];
    
    [datatask resume];
}


@end
