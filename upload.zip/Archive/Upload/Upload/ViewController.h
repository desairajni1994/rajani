//
//  ViewController.h
//  Upload
//
//  Created by MAC OS on 7/20/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *image;
- (IBAction)getdata:(id)sender;
- (IBAction)getperameter:(id)sender;
- (IBAction)Postdata:(id)sender;
- (IBAction)upload:(id)sender;


@end

