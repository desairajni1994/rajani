<?php
    $username=$_POST['username'];
    $password=$_POST['password'];
    $uploaddir = 'uploads/';
    $file = basename($_FILES['file']['name']);
    $uploadfile = $uploaddir . $file;
    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
        return true;
    }
    return false;
    ?>

