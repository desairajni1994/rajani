//
//  nz.m
//  jasonn
//
//  Created by MACOS on 7/19/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import "nz.h"

@interface nz ()
{
    NSMutableArray *finalnz,*logoo;
}

@end

@implementation nz

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSUserDefaults *nzz=[NSUserDefaults standardUserDefaults];
    finalnz=[nzz valueForKey:@"nz"];
    logoo=[nzz valueForKey:@"logo"];
    
    _name.text=[finalnz valueForKey:@"Name"];
    _age.text=[finalnz valueForKey:@"Age"];
    _blo.text=[finalnz valueForKey:@"BLong"];
    _bshort.text=[finalnz valueForKey:@"BShort"];
    _hlong.text=[finalnz valueForKey:@"HLong"];
    _hshort.text=[finalnz valueForKey:@"HShort"];
    _image.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[finalnz valueForKey:@"Image"]]]];
    _logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[logoo objectAtIndex:1]]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
