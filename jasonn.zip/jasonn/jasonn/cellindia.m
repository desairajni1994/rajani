//
//  cellindia.m
//  jasonn
//
//  Created by MAC OS on 7/18/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import "cellindia.h"

@implementation cellindia

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
