//
//  ViewController.m
//  jasonn
//
//  Created by MAC OS on 7/18/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import "ViewController.h"
#import "cellindia.h"
#import "detail.h"
#import "nz.h"

@interface ViewController (){
    NSMutableArray *finalind,*logoo,*finalnz;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    logoo=[[NSMutableArray alloc]init];
    _seg.selectedSegmentIndex=0;
    // Do any additional setup after loading the view, typically from a nib.
    NSString *str=@"https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.scorecard%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=";
    NSURL *url=[NSURL URLWithString:str];
    NSURLRequest *req=[NSURLRequest requestWithURL:url];
    NSURLSession *ses=[NSURLSession sharedSession];
    NSURLSessionDataTask *task=[ses dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSArray *arr=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSDictionary *queru=[arr valueForKey:@"query"];
        NSDictionary *result=[queru valueForKey:@"results"];
        NSDictionary *scor=[result valueForKey:@"Scorecard"];
        NSArray *team=[scor valueForKey:@"teams"];
        NSDictionary *ind=[team objectAtIndex:0];
        NSDictionary *logo=[[ind valueForKey:@"logo"] valueForKey:@"std"];
        [logoo addObject:logo];
        NSArray *squad=[ind valueForKey:@"squad"];

        finalind=[[NSMutableArray alloc]init];
        for (NSDictionary *temp in squad) {
            NSMutableDictionary *tempdic=[[NSMutableDictionary alloc]init];
            [tempdic setValue:[temp valueForKey:@"full"] forKey:@"Name"];
            [tempdic setValue:[temp valueForKey:@"age"] forKey:@"Age"];
            [tempdic setValue:[temp valueForKey:@"photo"] forKey:@"Image"];
            [tempdic setValue:[[temp valueForKey:@"bwlstyle"] valueForKey:@"long"] forKey:@"BLong"];
            [tempdic setValue:[[temp valueForKey:@"bwlstyle"] valueForKey:@"short"] forKey:@"BShort"];
            [tempdic setValue:[[temp valueForKey:@"hand"] valueForKey:@"long"] forKey:@"HLong"];
            [tempdic setValue:[[temp valueForKey:@"hand"] valueForKey:@"short"] forKey:@"HShort"];
            
            [finalind addObject:tempdic];
        }
        
        
        NSDictionary *nz=[team objectAtIndex:1];
        NSDictionary *nzlogo=[[nz valueForKey:@"logo"] valueForKey:@"std"];
        [logoo addObject:nzlogo];
        NSArray *nsquad=[nz valueForKey:@"squad"];
        
        finalnz=[[NSMutableArray alloc]init];
        for (NSDictionary *temp in nsquad) {
            NSMutableDictionary *tempdic=[[NSMutableDictionary alloc]init];
            [tempdic setValue:[temp valueForKey:@"full"] forKey:@"Name"];
            [tempdic setValue:[temp valueForKey:@"age"] forKey:@"Age"];
            [tempdic setValue:[temp valueForKey:@"photo"] forKey:@"Image"];
            [tempdic setValue:[[temp valueForKey:@"bwlstyle"] valueForKey:@"long"] forKey:@"BLong"];
            [tempdic setValue:[[temp valueForKey:@"bwlstyle"] valueForKey:@"short"] forKey:@"BShort"];
            [tempdic setValue:[[temp valueForKey:@"hand"] valueForKey:@"long"] forKey:@"HLong"];
            [tempdic setValue:[[temp valueForKey:@"hand"] valueForKey:@"short"] forKey:@"HShort"];
            
            [finalnz addObject:tempdic];
        }
        [_tbl reloadData];
        
        
        NSUserDefaults *india=[NSUserDefaults standardUserDefaults];
        [india setObject:finalind forKey:@"india"];
        [india setObject:logoo forKey:@"logo"];
        
        NSUserDefaults *nzz=[NSUserDefaults standardUserDefaults];
        [nzz setObject:finalnz forKey:@"nz"];
    }];
    
    [task resume];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_seg.selectedSegmentIndex==0) {
        return finalind.count;
    }else{
        return finalnz.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_seg.selectedSegmentIndex==0) {
        cellindia *mycell=[tableView dequeueReusableCellWithIdentifier:@"cellindia"];
        mycell.name.text=[[finalind objectAtIndex:indexPath.row] valueForKey:@"Name"];
        mycell.photo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[finalind objectAtIndex:indexPath.row] valueForKey:@"Image"]]]];
        mycell.logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[logoo objectAtIndex:0]]]];
        return mycell;
    }else{
        cellindia *mynz=[tableView dequeueReusableCellWithIdentifier:@"cellindia"];
        mynz.name.text=[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Name"];
        mynz.photo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Image"]]]];
        mynz.logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[logoo objectAtIndex:1]]]];
        return mynz;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_seg.selectedSegmentIndex==0) {
        NSUserDefaults *india=[NSUserDefaults standardUserDefaults];
        [india setObject:[finalind objectAtIndex:indexPath.row] forKey:@"india"];
        [india setObject:logoo forKey:@"logo"];
        
        detail *nav=[self.storyboard instantiateViewControllerWithIdentifier:@"detail"];
        [self.navigationController pushViewController:nav animated:YES];
    }else{
        NSUserDefaults *nzz=[NSUserDefaults standardUserDefaults];
        [nzz setObject:[finalnz objectAtIndex:indexPath.row] forKey:@"nz"];
        [nzz setObject:logoo forKey:@"logo"];
        
        nz *navv=[self.storyboard instantiateViewControllerWithIdentifier:@"nz"];
        [self.navigationController pushViewController:navv animated:YES];

    }
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
