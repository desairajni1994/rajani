
//
//  detail.m
//  jasonn
//
//  Created by MACOS on 7/19/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import "detail.h"

@interface detail (){
    NSMutableArray *finalind,*logoo;
}

@end

@implementation detail

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSUserDefaults *india=[NSUserDefaults standardUserDefaults];
    finalind=[india valueForKey:@"india"];
    logoo=[india valueForKey:@"logo"];
    
    NSLog(@"%@",finalind);
    
    _name.text=[finalind valueForKey:@"Name"];
    _age.text=[finalind valueForKey:@"Age"];
    _blong.text=[finalind valueForKey:@"BLong"];
    _bshort.text=[finalind valueForKey:@"BShort"];
    _hlong.text=[finalind valueForKey:@"HLong"];
    _hshort.text=[finalind valueForKey:@"HShort"];
    _image.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[finalind valueForKey:@"Image"]]]];
    _logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[logoo objectAtIndex:0]]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
