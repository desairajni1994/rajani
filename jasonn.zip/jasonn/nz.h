//
//  nz.h
//  jasonn
//
//  Created by MACOS on 7/19/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface nz : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *logo;
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *age;
@property (weak, nonatomic) IBOutlet UILabel *blo;
@property (weak, nonatomic) IBOutlet UILabel *bshort;
@property (weak, nonatomic) IBOutlet UILabel *hlong;
@property (weak, nonatomic) IBOutlet UILabel *hshort;

@end
