//
//  AppDelegate.h
//  PDFDownloader
//
//  Created by Malek T. on 10/27/15.
//  Copyright © 2015 Medigarage Studios LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

