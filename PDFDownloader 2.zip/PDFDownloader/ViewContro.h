//
//  ViewContro.h
//  PDFDownloader
//
//  Created by MAC OS on 7/25/16.
//  Copyright © 2016 Medigarage Studios LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewContro : UIViewController

@end
