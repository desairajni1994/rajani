//
//  AppDelegate.h
//  localdatabase
//
//  Created by MACOS on 7/13/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property(retain,nonatomic)NSString *DefaultPath;

-(void)connection;

@end

