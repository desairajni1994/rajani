//
//  ViewController.h
//  localdatabase
//
//  Created by MACOS on 7/13/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txtid;
@property (weak, nonatomic) IBOutlet UITextField *txtname;
@property (weak, nonatomic) IBOutlet UITextField *txtcity;
- (IBAction)btn_insert:(id)sender;
- (IBAction)btn_select:(id)sender;
- (IBAction)delet:(id)sender;
- (IBAction)update:(id)sender;

@end

