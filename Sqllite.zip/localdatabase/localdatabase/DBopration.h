//
//  DBopration.h
//  localdatabase
//
//  Created by MACOS on 7/13/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "AppDelegate.h"
@interface DBopration : NSObject
{
    AppDelegate *appdel;
    sqlite3 *mydatabase;
}

@property(retain,nonatomic)NSString *mypath;

-(BOOL)InsertUpdateDelete:(NSString*)query;
-(NSMutableArray*)select:(NSString*)query;

@end
