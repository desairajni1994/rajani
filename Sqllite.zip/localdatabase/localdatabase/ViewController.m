//
//  ViewController.m
//  localdatabase
//
//  Created by MACOS on 7/13/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "DBopration.h"

@interface ViewController (){
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_insert:(id)sender {
    
    DBopration *obj=[[DBopration alloc]init];
    NSString *str=[NSString stringWithFormat:@"insert into mytable values(%@,'%@','%@')",_txtid.text,_txtname.text,_txtcity.text];
    
    BOOL i = [obj InsertUpdateDelete:str];
    
    if (i) {
        NSLog(@"inserted");
    }
    else
    {
        NSLog(@"not inserted");
    }
    _txtname.text=_txtcity.text=_txtid.text=@"";

}

- (IBAction)btn_select:(id)sender {
    
    DBopration *obj=[[DBopration alloc]init];
    
    NSString *str=[NSString stringWithFormat:@"select * from mytable where id=%@",_txtid.text];
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    arr=[obj select:str];
    if (arr.count > 0) {
        _txtname.text=[[arr objectAtIndex:0] objectAtIndex:1];
        _txtcity.text=[[arr objectAtIndex:0] objectAtIndex:2];
        NSLog(@"%@",arr);
    }else
    {
        _txtid.text=@"";
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Select" message:@"No Data Found" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }

}

- (IBAction)delet:(id)sender {
    DBopration *obj=[[DBopration alloc]init];
    
    NSString *str=[NSString stringWithFormat:@"delete  from mytable where id=%@",_txtid.text];
    
    BOOL i = [obj InsertUpdateDelete:str];
    
    if (i) {
        NSLog(@"delete");
    }
    else
    {
        NSLog(@"not delete");
    }
    
}

- (IBAction)update:(id)sender {
    DBopration *obj=[[DBopration alloc]init];
    
    NSString *str=[NSString stringWithFormat:@"UPDATE mytable SET name='%@',city='%@' WHERE id='%@'",_txtname.text,_txtcity.text,_txtid.text];
    
    
    BOOL a= [obj InsertUpdateDelete:str];
    if (a) {
        NSLog(@"updated");
        
    }
    else
    {
        NSLog(@"not updated");
    }
    _txtname.text=_txtcity.text=_txtid.text=@"";
}
@end
