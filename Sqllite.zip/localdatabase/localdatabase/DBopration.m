//
//  DBopration.m
//  localdatabase
//
//  Created by MACOS on 7/13/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "DBopration.h"

@implementation DBopration
-(id)init
{
    if (self==[super init])
    {
        appdel=(AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        _mypath=[NSString stringWithString:appdel.DefaultPath];
    }
    return self;
}
-(BOOL)InsertUpdateDelete:(NSString *)query
{
    
    BOOL result=NO;
    
    sqlite3_stmt *stmt;
    
    if (sqlite3_open([_mypath UTF8String], &mydatabase)==SQLITE_OK)
    {
        if (sqlite3_prepare_v2(mydatabase, [query UTF8String], -1, &stmt, nil)==SQLITE_OK)
        {
            sqlite3_step(stmt);
            result=YES;
        }
        sqlite3_finalize(stmt);
    }
    sqlite3_close(mydatabase);
    
    return result;
}

-(NSMutableArray*)select:(NSString *)query
{
    NSMutableArray *result=[[NSMutableArray alloc]init];
    
    
    if (sqlite3_open([_mypath UTF8String],&mydatabase)==SQLITE_OK)
    {
        sqlite3_stmt *comstmt;
        
        if (sqlite3_prepare_v2(mydatabase,[query UTF8String],-1,&comstmt,nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(comstmt)==SQLITE_ROW)
            {
                
                NSMutableArray *temp=[[NSMutableArray alloc]init];
                
                NSString *stno=[[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(comstmt,0)];
                
                NSString *stname=[[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(comstmt,1)];
                
                NSString *stcity=[[NSString alloc]initWithUTF8String:(char *)sqlite3_column_text(comstmt,2)];
                
                
                
                [temp addObject:stno];
                [temp addObject:stname];
                [temp addObject:stcity];
                
                
                [result addObject:temp];
                
            };
    
        }
    }
    
    return result;
}

@end
