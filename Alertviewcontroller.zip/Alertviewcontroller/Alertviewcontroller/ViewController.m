//
//  ViewController.m
//  Alertviewcontroller
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "okk.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)alert:(id)sender {
    UIAlertController *aler=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Hello" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *act){
        okk *ss=[self.storyboard instantiateViewControllerWithIdentifier:@"ok"];
        [self.navigationController pushViewController:ss animated:YES];
    }];
    
    UIAlertAction *Cancle=[UIAlertAction actionWithTitle:@"Cancle" style:UIAlertActionStyleDefault handler:^(UIAlertAction *act){
        NSLog(@"Cancle");
    }];
    [aler addAction:ok];
    [aler addAction:Cancle];
    [self presentViewController:aler animated:YES completion:nil];
}

- (IBAction)alerttext:(id)sender {
    UIAlertController *aler=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Hello" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *act){
        okk *ss=[self.storyboard instantiateViewControllerWithIdentifier:@"ok"];
        [self.navigationController pushViewController:ss animated:YES];
    }];
    
    UIAlertAction *Cancle=[UIAlertAction actionWithTitle:@"Cancle" style:UIAlertActionStyleDefault handler:^(UIAlertAction *act){
        NSLog(@"Cancle");
    }];
    
    UIAlertAction *des=[UIAlertAction actionWithTitle:@"Destrictive" style:UIAlertActionStyleDefault handler:^(UIAlertAction *act){
        NSLog(@"Destrictive");
    }];
    
    [aler addTextFieldWithConfigurationHandler:^(UITextField *text){
            text.placeholder=@"Name";
    }];
    
    [aler addTextFieldWithConfigurationHandler:^(UITextField *txt){
        txt.placeholder=@"Password";
    }];
    
    [aler addAction:ok];
    [aler addAction:Cancle];
     [aler addAction:des];
    [self presentViewController:aler animated:YES completion:nil];
}
@end
