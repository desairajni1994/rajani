//
//  ViewController.m
//  multi
//
//  Created by MACOS on 09/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnselect:(id)sender {
    
    
    QBImagePickerController *imagePickerController = [QBImagePickerController new];
    imagePickerController.delegate = self;
    imagePickerController.allowsMultipleSelection = YES;
    imagePickerController.maximumNumberOfSelection = 6;
    imagePickerController.showsNumberOfSelectedAssets = YES;
    
    [self presentViewController:imagePickerController animated:YES completion:NULL];
    
}

- (void)qb_imagePickerController:(QBImagePickerController *)imagePickerController didFinishPickingAssets:(NSArray *)assets {
    
    
    PHImageManager *imageManager = [PHImageManager new];
    
    for (int i=0; i<[assets count]; i++) {
        
        PHAsset *asset=[assets objectAtIndex:i];
        
        if (i==0) {
            [imageManager requestImageDataForAsset:asset
                                           options:0
                                     resultHandler:^(NSData *imageData, NSString *dataUTI, UIImageOrientation orientation, NSDictionary *info) {
                                         UIImage *image = [UIImage imageWithData:imageData];
                                         
                                         _imag1.image=image;
                                         
                                         // Do something with image
                                     }];
        }
        
        else if (i==1)
        {
            [imageManager requestImageDataForAsset:asset
                                           options:0
                                     resultHandler:^(NSData *imageData, NSString *dataUTI, UIImageOrientation orientation, NSDictionary *info) {
                                         UIImage *image = [UIImage imageWithData:imageData];
                                         
                                         _imag2.image=image;
                                         
                                         // Do something with image
                                     }];

        }
        else if (i==2)
        {
            [imageManager requestImageDataForAsset:asset
                                           options:0
                                     resultHandler:^(NSData *imageData, NSString *dataUTI, UIImageOrientation orientation, NSDictionary *info) {
                                         UIImage *image = [UIImage imageWithData:imageData];
                                         
                                         _imag2.image=image;
                                         
                                         // Do something with image
                                     }];

        }
        else if(i==3)
        {
            [imageManager requestImageDataForAsset:asset
                                           options:0
                                     resultHandler:^(NSData *imageData, NSString *dataUTI, UIImageOrientation orientation, NSDictionary *info) {
                                         UIImage *image = [UIImage imageWithData:imageData];
                                         
                                         _img3.image=image;
                                         
                                         // Do something with image
                                     }];

        }
        
        
        
    }
    
    
    [self dismissViewControllerAnimated:YES completion:NULL];
}

@end
