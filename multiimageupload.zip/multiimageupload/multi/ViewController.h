//
//  ViewController.h
//  multi
//
//  Created by MACOS on 09/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QBImagePickerController.h>

@interface ViewController : UIViewController<QBImagePickerControllerDelegate>

- (IBAction)btnselect:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *imag1;
@property (weak, nonatomic) IBOutlet UIImageView *img3;
@property (weak, nonatomic) IBOutlet UIImageView *img4;

@property (weak, nonatomic) IBOutlet UIImageView *imag2;


@property (weak, nonatomic) IBOutlet UIImageView *img5;

@end

