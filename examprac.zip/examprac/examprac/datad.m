//
//  datad.m
//  examprac
//
//  Created by MACOS on 8/3/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "datad.h"
#import "ViewController.h"
#import "regis.h"
@interface datad ()
{
    NSMutableDictionary *dic;
    NSUserDefaults *ns;
}
@end

@implementation datad

- (void)viewDidLoad {
    [super viewDidLoad];
    
    ns=[NSUserDefaults standardUserDefaults];
    dic=[[NSMutableDictionary alloc]init];
    
    dic=[ns valueForKey:@"dat"];
    NSLog(@"%@",dic);
    
    for(NSMutableDictionary *d1 in dic)
    {
        _lblfname.text=[d1 valueForKey:@"firstname"];

        _lbllname.text=[d1 valueForKey:@"lastname"];
        _lblemail.text=[d1 valueForKey:@"email"];
        _lblgender.text=[d1 valueForKey:@"gender"];
        _lblbirthdate.text=[d1 valueForKey:@"birthdate"];
        _lblcourse.text=[d1 valueForKey:@"course"];
    }
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnlogout:(id)sender {
    [ns setObject:@"" forKey:@"ck"];
    
    //ViewController *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"rootv"];
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}
@end
