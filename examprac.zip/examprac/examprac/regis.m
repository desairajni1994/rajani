//
//  regis.m
//  examprac
//
//  Created by MACOS on 8/3/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "regis.h"
#import <AssetsLibrary/AssetsLibrary.h>

@interface regis ()
{
#define REGEX_USER_NAME @"[A-Za-z0-9]{3,10}"
#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD @"[A-Za-z0-9]{6,20}"
#define REGEX_PHONE_DEFAULT @"[0-9]{10,10}"
    
    UITapGestureRecognizer *tap;
    NSString *im,*gen;
    NSMutableArray *arr;
    NSString *finalpath;
}
@end

@implementation regis

- (void)viewDidLoad {
    [super viewDidLoad];
    [_txtemail addRegx:REGEX_EMAIL withMsg:@"invalid Email"];
    
    _txtemail.presentInView=self.view;
    
    [_txtpassword addRegx:REGEX_PASSWORD withMsg:@"invalid Password"];
    
    _txtpassword.presentInView=self.view;
    
    [_txtfname addRegx:REGEX_USER_NAME withMsg:@"invalid Email"];
    
    _txtfname.presentInView=self.view;
    
    [_txtlname addRegx:REGEX_USER_NAME withMsg:@"invalid Password"];
    
    _txtlname.presentInView=self.view;
    
    _tblview.hidden=YES;
    _imgprof.userInteractionEnabled=true;
    tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handle:)];
    tap.numberOfTapsRequired=1;
    [_imgprof addGestureRecognizer:tap];
    arr=[[NSMutableArray alloc]initWithObjects:@"MCA",@"MBA",@"BBA",@"BCA", nil];
    
    
    // Do any additional setup after loading the view.
}

- (void)handle:(UITapGestureRecognizer*)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];

}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.imgprof.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    NSURL *refURL = [info valueForKey:UIImagePickerControllerReferenceURL];
    
    // define the block to call when we get the asset based on the url (below)
    ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
    {
        ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
        NSLog(@"[imageRep filename] : %@", [imageRep filename]);
        UILabel *path=[[UILabel alloc] init];
        path.text= [imageRep filename];
        NSString *lpaath = @"http://app.hirededicated.com/test//upload/";
        finalpath = [lpaath stringByAppendingString:path.text];
    };
    
    // get the asset library and fetch the asset based on the ref url (pass in block above)
    ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
    [assetslibrary assetForURL:refURL resultBlock:resultblock failureBlock:nil];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cells" forIndexPath:indexPath];
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _txtcourse.text=[arr objectAtIndex:indexPath.row];
    _tblview.hidden=YES;
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 6) {
        _tblview.hidden=NO;
        return false;
    }
    else
    {
        return true;
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnsubmit:(id)sender {
    
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"firstname=%@&lastname=%@&email=%@&password=%@&profileme=%@&birthdate=%@&gender=%@&course=%@",_txtfname.text,_txtlname.text,_txtemail.text,_txtpassword.text,finalpath,_txtbirthdate.text,gen,_txtcourse.text];
    
    
    NSURL *url=[NSURL URLWithString:@"http://app.hirededicated.com/test/api/signup/"];
    
    NSData *postData = [post dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSMutableDictionary *d=[[NSMutableDictionary alloc]init];
    d=[NSJSONSerialization JSONObjectWithData:urlData options:kNilOptions error:nil];
    NSLog(@"%@",d.description);
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)segclick:(id)sender {
    gen=[[NSString alloc]init];
    if (_seggender.selectedSegmentIndex == 0) {
            gen=@"male";
    } else {
        gen=@"female";
    }
}
@end
