//
//  ViewController.h
//  examprac
//
//  Created by MACOS on 8/3/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"

@interface ViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtemail;

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtpassword;


- (IBAction)btnsubmit:(id)sender;

- (IBAction)btnregister:(id)sender;

@end

