//
//  ViewController.m
//  examprac
//
//  Created by MACOS on 8/3/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "registration.h"
#import "datad.h"

@interface ViewController ()
{
    NSString *email,*pwd,*ncheck;
    NSUserDefaults *ns;
    
#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD @"[A-Za-z0-9]{6,20}"
}
@end

@implementation ViewController

-(void)viewDidAppear:(BOOL)animated
{
    _txtemail.text=@"";
    _txtpassword.text=@"";
    ncheck=[[NSString alloc]init];
    ncheck=[ns valueForKey:@"ck"];
    
    //    if (![ncheck isEqualToString:@""]) {
    //        datad *dtd=[self.storyboard instantiateViewControllerWithIdentifier:@"datadisp"];
    //        [self.navigationController pushViewController:dtd animated:YES];
    //    }
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_txtemail addRegx:REGEX_EMAIL withMsg:@"invalid Email"];
    
    _txtemail.presentInView=self.view;
    
    [_txtpassword addRegx:REGEX_PASSWORD withMsg:@"invalid Password"];
    
    _txtpassword.presentInView=self.view;
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnsubmit:(id)sender {
    if ([_txtemail validate] && [_txtpassword validate]) {
    NSString *post =[[NSString alloc] initWithFormat:@"username=%@&password=%@",_txtemail.text,_txtpassword.text];
    
    NSURL *url=[NSURL URLWithString:@"http://app.hirededicated.com/test/api/signup/checklogin.php?"];
    
    NSData *postData = [post dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSMutableDictionary *d=[[NSMutableDictionary alloc]init];
    d=[NSJSONSerialization JSONObjectWithData:urlData options:kNilOptions error:nil];
    
    email=[[NSString alloc]init];
    pwd=[[NSString alloc]init];
    
    for(NSMutableDictionary *a in d)
    {
        email=[a valueForKey:@"email"];
        pwd=[a valueForKey:@"password"];
        
    }
    
    if ([_txtemail.text isEqualToString:email] && [_txtpassword.text isEqualToString:pwd]) {
        ns=[NSUserDefaults standardUserDefaults];
        [ns setObject:d forKey:@"dat"];
        [ns setObject:@"1" forKey:@"ck"];
        datad *dtd=[self.storyboard instantiateViewControllerWithIdentifier:@"datadisp"];
        [self.navigationController pushViewController:dtd animated:YES];
        
    } else {
        NSLog(@"Username Password Mismatch");
    }
    NSLog(@"%@",d.description);
    }
    else{
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Check Detail" message:@"Wrond email and Password" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

- (IBAction)btnregister:(id)sender {
    registration *r=[self.storyboard instantiateViewControllerWithIdentifier:@"reg"];
    [self.navigationController pushViewController:r animated:YES];
}
@end
