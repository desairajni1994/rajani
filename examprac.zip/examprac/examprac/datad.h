//
//  datad.h
//  examprac
//
//  Created by MACOS on 8/3/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface datad : UIViewController
@property (weak, nonatomic) IBOutlet UIView *v1;
@property (weak, nonatomic) IBOutlet UIImageView *img;


@property (weak, nonatomic) IBOutlet UILabel *lblfname;

@property (weak, nonatomic) IBOutlet UILabel *lbllname;

@property (weak, nonatomic) IBOutlet UILabel *lblemail;

@property (weak, nonatomic) IBOutlet UILabel *lblgender;

@property (weak, nonatomic) IBOutlet UILabel *lblbirthdate;

@property (weak, nonatomic) IBOutlet UILabel *lblcourse;


- (IBAction)btnlogout:(id)sender;


@end
