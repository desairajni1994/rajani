//
//  regis.h
//  examprac
//
//  Created by MACOS on 8/3/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"

@interface regis : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imgprof;

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtfname;

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtlname;



@property (weak, nonatomic) IBOutlet TextFieldValidator *txtemail;

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtbirthdate;
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtpassword;

@property (weak, nonatomic) IBOutlet UISegmentedControl *seggender;

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtcourse;
- (IBAction)btnsubmit:(id)sender;
- (IBAction)segclick:(id)sender;


@property (weak, nonatomic) IBOutlet UITableView *tblview;


@end
