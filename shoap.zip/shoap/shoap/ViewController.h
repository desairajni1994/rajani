//
//  ViewController.h
//  shoap
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MacOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate>
{
    NSMutableData *responseData;
    
    NSString *strcontent;
    
}
- (IBAction)btnact:(id)sender;


@end

