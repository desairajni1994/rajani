//
//  ViewController.m
//  shoap
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MacOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnact:(id)sender {
    NSString *str=@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
    "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
    "<soap:Body>"
    "<add xmlns=\"http://tempuri.org/\">\n"
    "<x>10</x>\n"
    "<y>20</y>\n"
    "</add>\n"
    "</soap:Body>\n"
    "</soap:Envelope>\n";
   
    NSURL *url = [NSURL URLWithString:@"http://www.morningbatch.somee.com/WebService.asmx"];
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
    NSString *msgLength = [NSString stringWithFormat:@"%lu", (unsigned long)[str length]];
    
    [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue:msgLength forHTTPHeaderField:@"Content-Length"];
    [theRequest addValue:@"http://tempuri.org/add" forHTTPHeaderField:@"SOAPAction"];

    NSLog(@"%@",str);
    
    [theRequest setHTTPMethod:@"POST"];
    [theRequest setHTTPBody: [str dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLSession *session =[NSURLSession sharedSession];
    
    NSURLSessionDataTask *task =[session dataTaskWithRequest:theRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSString *theXML = [[NSString alloc] initWithBytes:
                            [data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        NSXMLParser *parse = [[NSXMLParser alloc]initWithData:data];
        parse.delegate = self;
        [parse parse];
        
    }];
    
    [task resume];

}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
    if ([elementName isEqualToString:@"addResult"]) {
        
        
        NSLog(@"result%@",strcontent);
        
        
    }
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    
    strcontent =string;
    
    
}

@end
