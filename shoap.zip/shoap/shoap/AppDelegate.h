//
//  AppDelegate.h
//  shoap
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MacOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

