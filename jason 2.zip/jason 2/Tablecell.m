//
//  Tablecell.m
//  jason
//
//  Created by MACOS on 8/30/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "Tablecell.h"

@implementation Tablecell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
