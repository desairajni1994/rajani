
//
//  detail.m
//  jason
//
//  Created by MACOS on 8/30/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "detail.h"
#import "ViewController.h"

@interface detail (){
    NSMutableArray *final;
}

@end

@implementation detail

- (void)viewDidLoad {
    [super viewDidLoad];
    NSUserDefaults *india=[NSUserDefaults standardUserDefaults];
    final=[india valueForKey:@"data"];
    NSLog(@"%@",final.description);
    // Do any additional setup after loading the view.
        _name.text=[final objectAtIndex:0];
        _age.text=[final objectAtIndex:1];
        _bshort.text=[final objectAtIndex:3];
        _hshort.text=[final objectAtIndex:4];
        _logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[final objectAtIndex:5]]]];
        _image.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[final objectAtIndex:2]]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
