//
//  ViewController.m
//  jason
//
//  Created by MACOS on 8/30/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "Tablecell.h"
#import "detail.h"

@interface ViewController (){
    NSMutableArray *finalindia,*finalnz,*flagg,*final;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    flagg=[[NSMutableArray alloc]init];
    final=[[NSMutableArray alloc]init];
    _seg.selectedSegmentIndex=0;
    // Do any additional setup after loading the view, typically from a nib.
    
//    NSMutableData *data=[[NSMutableData alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"File" ofType:@"json"]];
    
    NSString *str=@"https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.scorecard%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=";
    NSURL *url=[NSURL URLWithString:str];
    NSURLRequest *req=[NSURLRequest requestWithURL:url];
    NSURLSession *ses=[NSURLSession sharedSession];
    NSURLSessionDataTask *task=[ses dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSArray *arr=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSDictionary *que=[arr valueForKey:@"query"];
        NSDictionary *resul=[que valueForKey:@"results"];
        NSDictionary *sqr=[resul valueForKey:@"Scorecard"];
        NSArray *team=[sqr valueForKey:@"teams"];
        NSDictionary *ind=[team objectAtIndex:0];
        NSDictionary *flag=[[ind valueForKey:@"flag"] valueForKey:@"std"];
        [flagg addObject:flag];
        finalindia=[[NSMutableArray alloc]init];
        NSArray *squ=[ind valueForKey:@"squad"];
        for (NSDictionary *tem in squ) {
            NSMutableDictionary *india=[[NSMutableDictionary alloc]init];
            [india setValue:[tem valueForKey:@"full"] forKey:@"Name"];
            [india setValue:[tem valueForKey:@"age"] forKey:@"Age"];
            [india setValue:[tem valueForKey:@"photo"] forKey:@"Image"];
            [india setValue:[[tem valueForKey:@"bwlstyle"] valueForKey:@"short"] forKey:@"BShort"];
            [india setValue:[[tem valueForKey:@"hand"] valueForKey:@"short"] forKey:@"HShort"];
            
            [finalindia addObject:india];
        }
//        NSLog(@"%@",flag.description);
//        NSLog(@"%@",finalindia.description);
        
        NSDictionary *nz=[team objectAtIndex:1];
        NSDictionary *Nflag=[[nz valueForKey:@"flag"] valueForKey:@"std"];
        [flagg addObject:Nflag];
        finalnz=[[NSMutableArray alloc]init];
        NSArray *nsqu=[nz valueForKey:@"squad"];
        for (NSDictionary *Ntem in nsqu) {
            NSMutableDictionary *Nzz=[[NSMutableDictionary alloc]init];
            [Nzz setValue:[Ntem valueForKey:@"full"] forKey:@"Name"];
            [Nzz setValue:[Ntem valueForKey:@"age"] forKey:@"Age"];
            [Nzz setValue:[Ntem valueForKey:@"photo"] forKey:@"Image"];
            [Nzz setValue:[[Ntem valueForKey:@"bwlstyle"] valueForKey:@"short"] forKey:@"BShort"];
            [Nzz setValue:[[Ntem valueForKey:@"hand"] valueForKey:@"short"] forKey:@"HShort"];
            
            [finalnz addObject:Nzz];
        }
        
         [_tabl reloadData];
//        NSLog(@"%@",Nflag.description);
//        NSLog(@"%@",finalnz.description);
    }];
   
    [task resume];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_seg.selectedSegmentIndex==0) {
        return finalindia.count;
    }else
    {
        return finalnz.count;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_seg.selectedSegmentIndex==0) {
        Tablecell *myindia=[tableView dequeueReusableCellWithIdentifier:@"cell"];
        myindia.name.text=[[finalindia objectAtIndex:indexPath.row] valueForKey:@"Name"];
        myindia.logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[flagg objectAtIndex:0]]]];
        myindia.image.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[finalindia objectAtIndex:indexPath.row] valueForKey:@"Image"]]]];
        return myindia;
    }else{
        Tablecell *mynz=[tableView dequeueReusableCellWithIdentifier:@"cell"];
        mynz.name.text=[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Name"];
        mynz.logo.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[flagg objectAtIndex:1]]]];
        mynz.image.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Image"]]]];
        return mynz;
    }

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_seg.selectedSegmentIndex==0) {
        final=[[NSMutableArray alloc]init];
        [final addObject:[[finalindia objectAtIndex:indexPath.row] valueForKey:@"Name"]];
        [final addObject:[[finalindia objectAtIndex:indexPath.row] valueForKey:@"Age"]];
        [final addObject:[[finalindia objectAtIndex:indexPath.row] valueForKey:@"Image"]];
        [final addObject:[[finalindia objectAtIndex:indexPath.row] valueForKey:@"BShort"]];
        [final addObject:[[finalindia objectAtIndex:indexPath.row] valueForKey:@"HShort"]];
        [final addObject:[flagg objectAtIndex:0]];
    }
    else{
        final=[[NSMutableArray alloc]init];
         [final addObject:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Name"]];
        [final addObject:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Age"]];
        [final addObject:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"Image"]];
        [final addObject:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"BShort"]];
        [final addObject:[[finalnz objectAtIndex:indexPath.row] valueForKey:@"HShort"]];
        [final addObject:[flagg objectAtIndex:1]];
        
    }
    NSUserDefaults *india=[NSUserDefaults standardUserDefaults];
    [india setObject:final forKey:@"data"];
    
    detail *nav=[self.storyboard instantiateViewControllerWithIdentifier:@"Detail"];
    [self.navigationController pushViewController:nav animated:NO];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
