//
//  AppDelegate.h
//  jason
//
//  Created by MACOS on 8/30/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

