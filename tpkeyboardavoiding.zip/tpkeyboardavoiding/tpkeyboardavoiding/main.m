//
//  main.m
//  tpkeyboardavoiding
//
//  Created by MAC OS on 5/13/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
