//
//  ViewController2.m
//  downloaddemo
//
//  Created by MACOS on 7/28/16.
//  Copyright © 2016 Marathe . All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 (){
    NSString *filepath;
}

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSUserDefaults *open=[NSUserDefaults standardUserDefaults];
    filepath=[open valueForKey:@"pdf"];
    self.web.allowsInlineMediaPlayback = YES;
    self.web.mediaPlaybackRequiresUserAction = NO;
    NSURL *targetURL = [NSURL fileURLWithPath:filepath];
    NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
    [_web loadRequest:request];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
