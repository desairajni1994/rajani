//
//  ViewController.h
//  downloaddemo
//
//  Created by Marathe  on 05/05/1938 Saka.
//  Copyright © 1938 Saka Marathe . All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AFNetworking/AFNetworking.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIProgressView *myprogress;
@property (weak, nonatomic) IBOutlet UILabel *lblper;

@end

