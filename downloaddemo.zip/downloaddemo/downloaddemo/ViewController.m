//
//  ViewController.m
//  downloaddemo
//
//  Created by Marathe  on 05/05/1938 Saka.
//  Copyright © 1938 Saka Marathe . All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.myprogress.progressTintColor = [UIColor greenColor];
    self.myprogress.trackTintColor = [UIColor darkGrayColor];
    _myprogress.layer.cornerRadius=20;
    CGFloat w = 150;
    CGFloat h = 20;
    [self.myprogress addConstraint:[NSLayoutConstraint constraintWithItem:self.myprogress attribute:NSLayoutAttributeWidth relatedBy:0 toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:w]];
    [self.myprogress addConstraint:[NSLayoutConstraint constraintWithItem:self.myprogress attribute:NSLayoutAttributeHeight relatedBy:0 toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:h]];
    
    
    NSString *currentURL=@"http://www.axmag.com/download/pdfurl-guide.pdf";
    
//    NSString *currentURL=@"http://techslides.com/demos/sample-videos/small.mp4";
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:currentURL]];
    AFURLConnectionOperation *operation =   [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"Myfile.PDF"];
//    NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"Myfile.mp4"];

    operation.outputStream = [NSOutputStream outputStreamToFileAtPath:filePath append:NO];
    
    [operation setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
        _myprogress.progress = (float)totalBytesRead / totalBytesExpectedToRead;
        _lblper.text=[NSString stringWithFormat:@"%.f %%",((float)totalBytesRead / totalBytesExpectedToRead*100)];
    }];
    
    [operation setCompletionBlock:^{
        UIAlertController *ale=[UIAlertController alertControllerWithTitle:@"DownLoad" message:@"SucessFully Download" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok=[UIAlertAction actionWithTitle:@"Open File" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            ViewController2 *navv=[self.storyboard instantiateViewControllerWithIdentifier:@"v2"];
            [self.navigationController pushViewController:navv animated:YES];
        }];
        UIAlertAction *canl=[UIAlertAction actionWithTitle:@"Cancle" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [ale addAction:ok];
        [ale addAction:canl];
        [self presentViewController:ale animated:YES completion:nil];
        
    }];
    [operation start];
    
    NSUserDefaults *open=[NSUserDefaults standardUserDefaults];
    [open setObject:filePath forKey:@"pdf"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
