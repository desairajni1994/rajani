//
//  ViewController2.h
//  downloaddemo
//
//  Created by MACOS on 7/28/16.
//  Copyright © 2016 Marathe . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *web;

@end
