//
//  cell.m
//  xmlparsing
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "cell.h"

@implementation cell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
