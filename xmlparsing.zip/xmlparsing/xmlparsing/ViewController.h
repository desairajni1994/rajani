//
//  ViewController.h
//  xmlparsing
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray *arr;
    NSMutableDictionary *dic;
    NSString *str;
    
}


@end

