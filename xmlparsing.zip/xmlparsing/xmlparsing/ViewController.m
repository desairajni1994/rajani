//
//  ViewController.m
//  xmlparsing
//
//  Created by MACOS on 7/15/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"
#import "cell.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSString *strr=@"http://boi.org.il/currency.xml";
    NSURL *url=[[NSURL alloc] initWithString:strr];
    NSData *data=[NSData dataWithContentsOfURL:url];
    NSXMLParser *pars=[[NSXMLParser alloc] initWithData:data];
    pars.delegate=self;
    [pars parse];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)parserDidStartDocument:(NSXMLParser *)parser{
    arr=[[NSMutableArray alloc]init];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName attributes:(NSDictionary<NSString *, NSString *> *)attributeDict{
    if ([elementName isEqualToString:@"CURRENCY"]) {
        dic=[[NSMutableDictionary alloc]init];
    }
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    str=[NSString stringWithString:string];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName
{
    if ([elementName isEqualToString:@"NAME"] || [elementName isEqualToString:@"UNIT"] || [elementName isEqualToString:@"CURRENCYCODE"] || [elementName isEqualToString:@"COUNTRY"] || [elementName isEqualToString:@"RATE"] || [elementName isEqualToString:@"CHANGE"])
    {
        [dic setValue:str forKey:elementName];
    }
    if ([elementName isEqualToString:@"CURRENCY"]) {
        [arr addObject:dic];
    }
}

- (void)parserDidEndDocument:(NSXMLParser *)parser{
    NSLog(@"%@",arr.description);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arr.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    cell *mycell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    mycell.change.text=[[arr objectAtIndex:indexPath.row] valueForKey:@"CHANGE"];
    mycell.country.text=[[arr objectAtIndex:indexPath.row] valueForKey:@"COUNTRY"];
    mycell.currancy.text=[[arr objectAtIndex:indexPath.row] valueForKey:@"CURRENCYCODE"];
    mycell.name.text=[[arr objectAtIndex:indexPath.row] valueForKey:@"NAME"];
    mycell.rate.text=[[arr objectAtIndex:indexPath.row] valueForKey:@"RATE"];
    mycell.unit.text=[[arr objectAtIndex:indexPath.row] valueForKey:@"UNIT"];
    return mycell;
}
@end
