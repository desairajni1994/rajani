//
//  ViewController.h
//  Animation
//
//  Created by MAC OS on 5/16/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btn_ani1:(UIButton*)sender;
@property (weak, nonatomic) IBOutlet UIView *view1;
- (IBAction)btn_ani2:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view2;
- (IBAction)btn_ani3:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view3;

@end

