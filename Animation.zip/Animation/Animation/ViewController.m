//
//  ViewController.m
//  Animation
//
//  Created by MAC OS on 5/16/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_ani1:(id)sender {
    
    
    
    
    CABasicAnimation *animation = [CABasicAnimation animation];
    animation.keyPath= @"position.x";
    animation.fromValue = @77;
    animation.toValue = @455;
    animation.duration = 4;
    
    [_view1.layer addAnimation:animation forKey:@"basic"];

    
}
- (IBAction)btn_ani2:(id)sender {
    
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
    animation.keyPath = @"position.x";
    animation.values = @[ @0, @10, @-10, @10, @0 ];
    animation.keyTimes = @[ @0, @(1 / 6.0), @(3 / 6.0), @(5 / 6.0), @1 ];
    animation.duration = 0.4;
    
    animation.additive = YES;
    
    [_view2.layer addAnimation:animation forKey:@"shake"];
}
- (IBAction)btn_ani3:(id)sender {
    
    CGRect boundingRect = CGRectMake(50, 50, 60, 60);
    
    CAKeyframeAnimation *orbit = [CAKeyframeAnimation animation];
    orbit.keyPath = @"position";
    orbit.path = CFAutorelease(CGPathCreateWithEllipseInRect(boundingRect, NULL));
    orbit.duration = 1;
    orbit.additive = YES;
    orbit.repeatCount = HUGE_VALF;
    orbit.calculationMode = kCAAnimationPaced;
    orbit.rotationMode = kCAAnimationRotateAuto;
    
    [_view3.layer addAnimation:orbit forKey:@"orbit"];
    
    
}
@end
