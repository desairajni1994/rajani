//
//  ViewController.m
//  designn
//
//  Created by MACOS on 7/22/16.
//  Copyright © 2016 MacOS. All rights reserved.
//

#import "ViewController.h"
#import <UICustomizeKit/BaseActivityView.h>
#import <UICustomizeKit/BaseButton.h>
#import <UICustomizeKit/BaseProgressView.h>
#import <UICustomizeKit/BaseRadialProgressView.h>
#import <UICustomizeKit/BaseSlider.h>
#import <UICustomizeKit/BaseSwitchView.h>
#import <UICustomizeKit/BaseText.h>
#import <UICustomizeKit/BaseTextField.h>
#import <UICustomizeKit/BaseTextView.h>

@interface ViewController (){
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // progress view example.
    NSArray *pcolors = @[[UIColor colorWithRed:72.0f/255 green:153.0f/255 blue:251.0f/255 alpha:1]];
    CGRect prect = { .origin.x = 20.0, .origin.y = 80.0, .size.width = 182.0, .size.height = 44.0 };
    BaseProgressView *progressView = [[BaseProgressView alloc] initWithFrame:prect];
    progressView.colors = pcolors;
    CGFloat *pcolorLocs = (CGFloat*)malloc(sizeof(CGFloat) * 2);
    pcolorLocs[0] = 0.0f;
    pcolorLocs[1] = 1.0f;
    progressView.colorRange = pcolorLocs;
    progressView.trackColors = @[[UIColor lightGrayColor]];
    progressView.trackRange = pcolorLocs;
    progressView.borderWidth = 1;
    progressView.borderColor = [UIColor colorWithWhite:0.4 alpha:1];
    progressView.rounding = 8;
    progressView.corners = UIRectCornerAllCorners;
    [progressView setProgress:0.75 animated:YES];
    progressView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:progressView];

    //slider example
    NSArray *scolors = @[[UIColor redColor]];
    CGRect srect = { .origin.x = 20.0, .origin.y = 150, .size.width = 182.0, .size.height = 44.0 };
    BaseSlider *slider = [[BaseSlider alloc] initWithFrame:srect];
    slider.colors = scolors;
    CGFloat *scolorLocs = (CGFloat*)malloc(sizeof(CGFloat) * 2);
    scolorLocs[0] = 0.0f;
    scolorLocs[1] = 1.0f;
    slider.colorRange = scolorLocs;
    slider.trackColors = @[[UIColor lightGrayColor]];
    slider.trackRange = scolorLocs;
    slider.thumbColors = @[[UIColor blackColor]];
    slider.thumbRange = scolorLocs;
    slider.thumbSelectedColors = @[[UIColor yellowColor]];
    slider.thumbSelectedRange = scolorLocs;
    
    [self.view addSubview:slider];
    
    
    //switch example
    CGRect rect = { .origin.x = 20.0, .origin.y = 200.0};
    BaseSwitchView *sw = [[BaseSwitchView alloc] initWithFrame:rect];
    sw.onText = @"Yes";
    sw.offText = @"No";
    sw.backgroundColor = [UIColor lightGrayColor];
    sw.onBackgroundColor = [UIColor blackColor];
    sw.onColor = [UIColor whiteColor];
    sw.offBackgroundColor = [UIColor redColor];
    sw.offColor = [UIColor whiteColor];
    [sw setOn:YES animated:NO];
    [self.view addSubview:sw];
    
    //textfield example
    CGRect rect4 = { .origin.x = 20.0, .origin.y = 250.0, .size.width = 182.0, .size.height = 44.0 };
    BaseTextField *textField = [[BaseTextField alloc] initWithFrame:rect4];
    textField.borderWidth = 1;
    textField.mainTextColor = [UIColor redColor];
    textField.borderColor = [UIColor colorWithWhite:0.8 alpha:1];
    textField.bodyColor = [UIColor colorWithWhite:0.9 alpha:1];
    [self.view addSubview:textField];
    
    
    //textView example
    CGRect rect5 = { .origin.x = 20.0, .origin.y = 300.0, .size.width = 182.0, .size.height = 44.0 };
    BaseTextView *textView = [[BaseTextView alloc] initWithFrame:rect5];
    textView.mainTextColor = [UIColor redColor];
    textView.borderWidth = 1;
    textView.borderColor = [UIColor colorWithWhite:0.9 alpha:1];
    
    [self.view addSubview:textView];

    //radial progress view example
    CGRect rect6 = { .origin.x = 20.0, .origin.y = 350.0, .size.width = 40, .size.height = 40 };
    BaseRadialProgressView *view = [[BaseRadialProgressView alloc] initWithFrame:rect6];
    view.borderColor = [UIColor greenColor];
    [view setProgress:0.8 animated:YES];
    
    [self.view addSubview:view];
    
    //ActivityView example
    CGRect rect7 = { .origin.x = 20.0, .origin.y = 400.0, .size.width = 40, .size.height = 40 };
    BaseActivityView *vieww = [[BaseActivityView alloc] initWithFrame:rect7];
    [self.view addSubview:vieww];
    [vieww startAnimating];
    
    [self.view addSubview:view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
