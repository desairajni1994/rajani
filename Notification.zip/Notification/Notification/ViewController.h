//
//  ViewController.h
//  Notification
//
//  Created by MACOS on 7/21/16.
//  Copyright © 2016 MacOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIDatePicker *datepikerr;
- (IBAction)save:(id)sender;

@property (weak, nonatomic) IBOutlet UITextField *text;

@end

