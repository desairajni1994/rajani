//
//  IconViewController.h
//  FlatUIKitExample
//
//  Created by Jamie Matthews on 12/24/14.
//
//

#import <UIKit/UIKit.h>

@interface IconViewController : UIViewController <UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@end
