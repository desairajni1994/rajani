//
//  ViewController.h
//  core data
//
//  Created by MACOS on 6/9/16.
//  Copyright (c) 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
@interface ViewController : UIViewController
{
    AppDelegate *appdel;
}
@property(strong,nonatomic) NSManagedObjectContext *context;
@property (strong,nonatomic) NSManagedObjectModel *mycontact;


@property (weak, nonatomic) IBOutlet UITextField *txtname;
@property (weak, nonatomic) IBOutlet UITextField *txtcity;

@property (weak, nonatomic) IBOutlet UITextField *txtmob;
@property (weak, nonatomic) IBOutlet UIButton *btninsert;
- (IBAction)btninsert:(id)sender;
- (IBAction)btnselect:(id)sender;
- (IBAction)btnupdate:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblmsg;
- (IBAction)btndelete:(id)sender;

@end

