//
//  ViewController.m
//  core data
//
//  Created by MACOS on 6/9/16.
//  Copyright (c) 2016 MACOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    appdel=[[UIApplication sharedApplication]delegate];
    
    _context= appdel.managedObjectContext;
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btninsert:(id)sender {
    
    _mycontact=[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:_context];
    
    [_mycontact setValue:_txtname.text forKey:@"name"];
    [_mycontact setValue:_txtcity.text forKey:@"city"];
    [_mycontact setValue:_txtmob.text forKey:@"mob"];
    
    NSError *err;
    
    [_context save:&err];
    
    _txtname.text=_txtcity.text=_txtmob.text=@"";
    
    
    
}

- (IBAction)btnselect:(id)sender {
    
    NSEntityDescription *enttiy=[NSEntityDescription entityForName:@"Student" inManagedObjectContext:_context];
    
    NSFetchRequest *request=[[NSFetchRequest alloc]init];
    
    [request setEntity:enttiy];
    
    NSPredicate *prd=[NSPredicate predicateWithFormat:@"(name=%@)",_txtname.text];
    
    
    [request setPredicate:prd];
    
    NSManagedObject *manage=nil;
    
    NSError *err;
    
    
    NSArray *arr=[_context executeFetchRequest:request error:&err];
    
    NSLog(@"%@",[arr description]);
    
    if ([arr count]>0) {
        
        
        manage=arr[0];
        
        _txtname.text=[manage valueForKey:@"name"];
        _txtcity.text=[manage valueForKey:@"city"                        ];
        _txtmob.text=[manage valueForKey:@"mob"];
        
    }

    
    
}

- (IBAction)btnupdate:(id)sender {
    
    NSEntityDescription *enttiy=[NSEntityDescription entityForName:@"Student" inManagedObjectContext:_context];
    
    NSFetchRequest *request=[[NSFetchRequest alloc]init];
    [request setEntity:enttiy];
    
    NSPredicate *prd=[NSPredicate predicateWithFormat:@"(name=%@)",_txtname.text];
    [request setPredicate:prd];
    NSManagedObject *manage=nil;
    
    NSError *err;
    
    
    NSArray *arr=[_context executeFetchRequest:request error:&err];
    
    if ([arr count]>0) {
        
        
        manage=arr[0];
        
       
        [manage setValue:_txtname.text forKey:@"name"];
        [manage setValue:_txtcity.text forKey:@"city"];
        [manage setValue:_txtmob.text forKey:@"mob"];
        
        [_context save:&err];
        
        
        _lblmsg.text=@"updateed";
        
    }
    
}
- (IBAction)btndelete:(id)sender {
    
    NSEntityDescription *enttiy=[NSEntityDescription entityForName:@"Student" inManagedObjectContext:_context];
    
    NSFetchRequest *request=[[NSFetchRequest alloc]init];
    [request setEntity:enttiy];
    
    NSPredicate *prd=[NSPredicate predicateWithFormat:@"(name=%@)",_txtname.text];
    [request setPredicate:prd
     ];
    
    
    NSManagedObject *manage=nil;
    
    NSError *err;
    
    
    NSArray *arr=[_context executeFetchRequest:request error:&err];
    
    for (NSManagedObject  *obj in arr) {
        
        
        [_context deleteObject:obj];
        
    }

    [_context save:&err];
    _lblmsg.text=@"deleted";

    
    
    
    
}
@end
