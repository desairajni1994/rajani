//
//  ViewController.m
//  image
//
//  Created by MAC OS on 2/25/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //imageupload
    UITapGestureRecognizer *tep=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imagepik)];
    tep.numberOfTapsRequired=1;
    _img.userInteractionEnabled=YES;
    [_img addGestureRecognizer:tep];
}

-(void)imagepik{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.mediaTypes = [[NSArray alloc] initWithObjects:(NSString *)kUTTypeMovie,nil];
    [self presentModalViewController:imagePicker animated:YES];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    NSString *mediaType = [info objectForKey: UIImagePickerControllerMediaType];
    
    if (CFStringCompare ((__bridge CFStringRef) mediaType, kUTTypeMovie, 0) == kCFCompareEqualTo) {
        NSURL *videoUrl=(NSURL*)[info objectForKey:UIImagePickerControllerMediaURL];
        NSString *moviePath = [videoUrl path];
        
        if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum (moviePath)) {
            UISaveVideoAtPathToSavedPhotosAlbum (moviePath, nil, nil, nil);
        }
    }
    [self dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)upload:(id)sender {
    int i=arc4random() % 9000 + 1000;
    NSString *imgname=[NSString stringWithFormat:@"PRO%d.mp4",i];
    
    //  NSData *imageToUpload = UIImageJPEGRepresentation(self.img.image, 90);
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:@"http://localhost"]];
    NSData *imageData = UIImageJPEGRepresentation(self.img.image, 0.5);
    
    // NSData *imageData = UIVideoAtPathIsCompatibleWithSavedPhotosAlbum([[NSBundle mainBundle] pathForResource:@"The.mp4" ofType:@"mp4"]);
    
    NSDictionary *parameters = @{@"username": @"tops", @"password" : @"surat"};
    
    AFHTTPRequestOperation *op = [manager POST:@"/rajni/index.php" parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        // [formData appendPartWithFileData:imageData name:@"file" fileName:@"he.jpeg" mimeType:@"image/jpeg"];
        [formData appendPartWithFileData:imageData name:@"file" fileName:imgname mimeType:@"video/mpeg"];
    }
                                       success:^(AFHTTPRequestOperation *operation, id responseObject) {
                                           NSLog(@"Success: %@ ***** %@", operation.responseString, responseObject);
                                       } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                                           NSLog(@"Error: %@ ***** %@", operation.responseString, error);
                                       }];
    [op start];
    

}
@end
