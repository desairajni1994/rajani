//
//  ViewController.h
//  txt
//
//  Created by MACOS on 5/22/16.
//  Copyright (c) 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"
@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtuname;
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtpassword;
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtmob;

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtemail;

@end

