//
//  ViewController.m
//  CoreLocation
//
//  Created by MACOS on 18/07/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    locationManager = [[CLLocationManager alloc]init]; // initializing locationManager
    locationManager.delegate = self; // we set the delegate of locationManager to self.
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;// setting the accuracy
    [locationManager requestWhenInUseAuthorization ];
    [locationManager requestAlwaysAuthorization];
    
    [locationManager startUpdatingLocation];  //requesting location updates
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
//    UIAlertView *errorAlert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"There was an error retrieving your location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
//    [errorAlert show];
    NSLog(@"Error: %@",error.description);
}
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *crnLoc = [locations lastObject];
    //latitude.text =
    NSString *lat=[NSString stringWithFormat:@"%.8f",crnLoc.coordinate.latitude];
    
   // longitude.text =
    
    NSString *lon=[NSString stringWithFormat:@"%.8f",crnLoc.coordinate.longitude];
   // NSString *s1 = [NSString stringWithFormat:@"%.0f m",crnLoc.altitude];
   // NSString *s2 = [NSString stringWithFormat:@"%.1f m/s", crnLoc.speed];
    
    
    NSLog(@"%@   %@     ",lat,lon);
}

@end
