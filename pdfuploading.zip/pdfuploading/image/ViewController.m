//
//  ViewController.m
//  image
//
//  Created by MAC OS on 2/25/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //  NSData *imageToUpload = UIImageJPEGRepresentation(self.img.image, 90);
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:@"http://localhost"]];
    
       // NSData *imageData = UIImageJPEGRepresentation(_img.image, 0.5);
    
    NSData *d2=[NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"i" ofType:@".pdf"]];
    
   // NSData *imageData = UIVideoAtPathIsCompatibleWithSavedPhotosAlbum([[NSBundle mainBundle] pathForResource:@"The.mp4" ofType:@"mp4"]);
    

    
    NSDictionary *parameters = @{@"username": @"tops", @"password" : @"surat"};
    
    AFHTTPRequestOperation *op = [manager POST:@"/rajni/index.php" parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        
        //do not put image inside parameters dictionary as I did, but append it!
        
       // [formData appendPartWithFileData:imageData name:@"file" fileName:@"he.jpeg" mimeType:@"image/jpeg"];
        [formData appendPartWithFileData:d2 name:@"file" fileName:@"i.pdf" mimeType:@"Pdf/pdf"];
    }
                                       success:^(AFHTTPRequestOperation *operation, id responseObject) {
                                           
                                           
                                           NSLog(@"Success: %@ ***** %@", operation.responseString, responseObject);
                                           
                                           
                                       } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                                           NSLog(@"Error: %@ ***** %@", operation.responseString, error);
                                       }];
    [op start];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
