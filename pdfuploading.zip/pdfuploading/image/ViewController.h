//
//  ViewController.h
//  image
//
//  Created by MAC OS on 2/25/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *img;

@end

