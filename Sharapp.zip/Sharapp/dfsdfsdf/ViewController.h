//
//  ViewController.h
//  dfsdfsdf
//
//  Created by MAC OS on 5/5/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btnclick:(id)sender;

@end

