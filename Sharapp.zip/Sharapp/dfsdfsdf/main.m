//
//  main.m
//  dfsdfsdf
//
//  Created by MAC OS on 5/5/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
